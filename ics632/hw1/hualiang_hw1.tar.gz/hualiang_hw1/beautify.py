import re
'''
This code beautify the raw data generate from  'perf stat | grep > file'
Such that it is easy to read and compute
'''
def warehouse():
   out = open('./data/beauty.dat', 'w') 
   with open('./data/raw.dat', 'r') as inputdata:
      line = ''
      item = ""
      count = 0
      for line in inputdata:
         if line =='':
            break
         if line.startswith('tile'):
            out.write(line)
            continue
         count += 1
         line = re.sub('[,@]', '', line)
         line = line.strip()
         line = line.split()
         for word in line:
            if is_number(word):
               item += str(word)
               if not count %3 == 0:
                  item += '\t'
         if count % 3 == 0:
            out.write(item)
            out.write("\n")
            item = "" 

   out.close()

def is_number(s):
   try:
      float(s)
      return True
   except ValueError:
      try:
         int(s)
         return True
      except ValueError:
         return False


warehouse()
