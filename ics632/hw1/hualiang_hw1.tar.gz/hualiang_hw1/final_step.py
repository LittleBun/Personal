def cal_ave():
    performance = open('./data/perf.dat', 'w')
    l1_miss = open('./data/l1_miss.dat', 'w')
    llc_miss = open('./data/llc_miss.dat', 'w')
    with open('./data/beauty.dat', 'r') as infile:
        line = ""
        count = 0
        perf = 0
        l1 = 0
        llc = 0
        for line in infile:
            if line == '':
                break
            if line.startswith('tile'):
                continue
            count += 1
            line = line.strip().split()
            l1 += int(line[0])
            llc += int(line[1])
            perf += float(line[2])
            if count % 10 == 0:
                performance.write(str(perf/10))
                l1_miss.write(str(l1/10))
                llc_miss.write(str(llc/10))
                performance.write('\n')
                l1_miss.write('\n')
                llc_miss.write('\n')
                perf = 0
                llc = 0
                l1 = 0
    performance.close()
    l1_miss.close()
    llc_miss.close()

cal_ave()
