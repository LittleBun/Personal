#include <stdio.h>
//#include <sys/time.h>

#ifndef N
    #define N 17600
#endif

#ifndef b
    #define b 50
#endif

double A[N][N];
double B[N][N];

int main() {
    //struct timeval start, end;
    //gettimeofday(&start, NULL);
    int i, j;
#ifdef BASIC
    for (i=0; i<N; i++) {
        for (j=0; j<N; j++) {
            A[i][j] += B[j][i];
        }
    }
    //printf("Runing basic algorithm\n");
#endif
#ifdef TILED
    int k, l;
    for(i=0; i<N; i+=b){
        for(j=0; j<N; j+=b){
            for(k=i; k<i+b && k<N; k++){
                for(l=j; l<j+b && l<N; l++){
                    A[k][l] += B[l][k];
                }
            }
        }
    }
    //printf("Runing tiled algorithm\n");
#endif
    //gettimeofday(&end, NULL);
    //printf("Seconds elapsed: %f\n", (end.tv_sec*1000000.0 + end.tv_usec - start.tv_sec*1000000.0 - start.tv_usec) / 1000000.0);
}

