from subprocess import call

def run_c_program():
    #call('rm output', shell=True)
    for i in range(1,301):
        with open("./data/raw.dat", "a") as myfile:
            myfile.write("tile size=")
            myfile.write(str(i))
            myfile.write("\n")
        for j in range(10):
            compile_command = 'icc exercise1.c -o exercise1 -mcmodel=medium -Ofast -D TILED -D N=17600 -D b='
            compile_command += str(i)
            call(compile_command, shell=True)
            run_command =""
            run_command +="perf stat"
            run_command +=" -e L1-dcache-load-misses"
            run_command +=" -e LLC-load-misses"
            run_command +=" ./exercise1"
            run_command +=" 2>&1"
            run_command +=" | grep -E 'time|L1-dcache|LLC'"
            run_command +=" >> ./data/raw.dat"
            call(run_command, shell=True)
            #run = 'sbatch exercise1.slurm'

run_c_program()
