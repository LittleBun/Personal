#include<stdio.h>
#include<omp.h>

#ifndef N
    #define N 2500
#endif

#ifndef P
    #define P 20
#endif

int A[N][N];
int B[N][N];
int C[N][N];
int main() {
    int i,j,k;
    long long sum = 0;

    omp_set_dynamic(0);
    omp_set_num_threads(P);

    for(i=0; i<N; i++){
        for(j=0; j<N; j++){
            A[i][j] = i + j;
            B[i][j] = i + j;
            C[i][j] = 0;
        }
    }

#ifdef p1
#pragma omp parallel for
    for(i=0; i<N; i++){
        for(j=0; j<N; j++){
            for(k=0; k<N; k++){
                C[i][j] += A[i][k] * B[k][j]; 
            }
        }
    }
#endif

#ifdef p2
    for(i=0; i<N; i++){
#pragma omp parallel for
        for(j=0; j<N; j++){
            for(k=0; k<N; k++){
                C[i][j] += A[i][k] * B[k][j]; 
            }
        }
    }
#endif

#ifdef p3
    for(i=0; i<N; i++){
        for(j=0; j<N; j++){
#pragma omp parallel for
            for(k=0; k<N; k++){
#pragma omp critical
                C[i][j] += A[i][k] * B[k][j]; 
            }
        }
    }
#endif

#ifdef s
    for(i=0; i<N; i++){
        for(j=0; j<N; j++){
            for(k=0; k<N; k++){
                C[i][j] += A[i][k] * B[k][j]; 
            }
        }
    }
#endif

    for(i=0; i<N; i++){
        sum += C[i][i];
    }
    printf("Diagonal sum = %ld\n", sum);
}
