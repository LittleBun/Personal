#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#include <signal.h>
#include <omp.h>

#define N 12000

#ifndef T
    #define T 400
#endif

int A[N+2][N+2];

int main(int argc, char **argv) {

    int num_threads;
    int num_iterations;

    int iter;
    int i,j;

    if (argc != 3) {
        fprintf(stderr,"Usage: %s <num threads> <num iterations>\n", argv[0]);
        exit(1);
    }

    if (sscanf(argv[1],"%d",&num_threads) != 1) {
        fprintf(stderr,"Invalid number of threads\n");
        exit(1);
    }

    if (sscanf(argv[2],"%d",&num_iterations) != 1) {
        fprintf(stderr,"Invalid number of iterations\n");
        exit(1);
    }

    //Fill in the array
    for (i=0; i < N+2; i++) {
        for (j=0; j < N+2; j++) {
            A[i][j] = i+j;
        }
    }

#ifdef s
    // Loop for num_iterations iterations
    for (iter = 0; iter < num_iterations; iter++) {
        for (i = 1; i < N+1; i++) {
            for (j = 1; j < N+1; j++) {
                A[i][j] = (3*A[i-1][j] + A[i+1][j] + 3*A[i][j-1] + A[i][j+1])/4;
            }
        }
    }
#endif

#ifdef p
    omp_set_num_threads(num_threads);
    // Loop for num_iterations iterations
    int s;
    int maxSum = 2*(N/T)-1;
    int ii, jj, iii, jjj;
    for (iter = 0; iter < num_iterations; iter++) {
        for(s = 0; s < maxSum; s++) {
            int z = s < (N/T) ? 0 : s-(N/T)+1;
#pragma omp parallel for
            for (i = z; i < s-z+1; i++) {
                for(ii=0; ii < T; ii++){
                    for(jj=0; jj< T; jj++){
                        iii = i*T+1+ii;
                        jjj = (s-i)*T+1+jj;
                        A[iii][jjj] = (3*A[iii-1][jjj] + A[iii+1][jjj] + 3*A[iii][jjj-1] + A[iii][jjj+1])/4;
                    }
                }
            }
        }
    }
#endif

    // Compute and print the sum of elements for correctness checking
    int sum =0 ;
    for (i=1; i < N; i++) {
        for (j=1; j < N; j++) {
            sum += A[i][j];
        }
    }
    fprintf(stderr,"sum = %d\n",sum);

    exit(0);
}
