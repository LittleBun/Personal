#!/usr/bin/env python2.7
import os
import sys
import subprocess
import string
import re

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as pyplot

perf_output_filename = "data/perf_output"

def parsePerfOutput(filename):
    elapsed = 0
    with open(filename) as f:
        lines = f.readlines()
    for line in lines:
        line = re.sub('[,]','', line)
        #print "line=", line
        tokens = string.capwords(line).split(" ")
        if(line.find("elapsed") > 0):
            elapsed = float(tokens[0])
    return elapsed

def runProgram(num_trials, command_line):
    m_elapsed = 0.0
    for i in range(0, num_trials):
        subprocess.check_call(command_line.split(" "), stdout=None)
        elapsed = parsePerfOutput(perf_output_filename)
        m_elapsed += elapsed
    return m_elapsed/num_trials

def runExperiments(sourcefile, plotfile):
    #perf_options="stat -o " + perf_output_filename
    compiler_flags = "-Ofast -openmp"
    
    num_iterations = 16
    num_trials = 10

    print "Sequential version:"
    os.system("icc -Ofast -D s -o ./exercise2 "+sourcefile)
    sequential_elapsed = runProgram(num_trials, "perf stat -o "+perf_output_filename+" ./exercise2 1 "+str(num_iterations))
    print "elapsed=", sequential_elapsed, "thread_num=0"

    print "Parallel version:"
    num_threads = [1]+range(2, 21, 1)
    elapsed_array1 = []
    sequential_elapsed_array = []
    os.system("icc "+compiler_flags+" "+sourcefile+" -D p -o ./exercise2")
    for thread_num in num_threads:
        elapsed = runProgram(num_trials,"perf stat -o "+perf_output_filename+" ./exercise2 "+ str(thread_num)+" "+ str(num_iterations))
        print "elapsed=", elapsed, "thread_num=", thread_num
        elapsed_array1.append(elapsed)
        sequential_elapsed_array.append(sequential_elapsed)

    pyplot.figure(1)
    pyplot.plot(num_threads, [x for x in elapsed_array1], 'r-', label='parallel elpased', linewidth=3.0)
    pyplot.plot(num_threads, [x for x in sequential_elapsed_array], 'g-', label='sequential elpased', linewidth=3.0)
    pyplot.ylim(2, max(sequential_elapsed_array)+1)
    pyplot.legend()
    pyplot.xlabel("Number of Threads")
    pyplot.ylabel("Elapsed Time")
    pyplot.savefig(plotfile,bbox_inchex='tight')
    print "Figure saved to file to file '"+ plotfile +"'"
    return 

runExperiments("./exercise2.c", "./naive.pdf")
